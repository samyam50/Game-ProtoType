#pragma once

#include <map>

#define SDL_MAIN_HANDLED
#include <SDL.h>

#include "asset.h"
#include "texture.h"
#include "animated_texture.h"

class Assets
{
public:
	Assets(SDL_Renderer* renderer);
	~Assets();

	Asset* get_asset(std::string id);

private:
	std::map<std::string, Asset*> _assets;
};