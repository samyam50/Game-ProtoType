#pragma once

struct Configuration
{
	bool should_display_ids = false;

	int window_width = 800;
	int window_height = 800;
};